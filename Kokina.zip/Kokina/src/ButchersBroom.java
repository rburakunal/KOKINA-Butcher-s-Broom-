import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class ButchersBroom extends JPanel {
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setPaint(new Color(0, 128, 0));
        int x = 50;
        int y = 50;
        int w = 100;
        int h = 100;
        int x1[] = {x + w / 2, x + w / 2, x + w / 4};
        int y1[] = {y, y + h / 2, y + h / 4};
        int x2[] = {x + w / 2, x + w / 2, x + 3 * w / 4};
        int y2[] = {y, y + h / 2, y + h / 4};
        g2d.draw(new Line2D.Double(x + w / 2, y + h / 2, x + w / 2, y + h));
        g2d.draw(new Line2D.Double(x + w / 2, y + h, x + w / 4, y + 3 * h / 4));
        g2d.draw(new Line2D.Double(x + w / 2, y + h, x + 3 * w / 4, y + 3 * h / 4));
        g2d.draw(new Polygon(x1, y1, 3));
        g2d.draw(new Polygon(x2, y2, 3));
        g2d.setPaint(new Color(255, 0, 0));
        g2d.fillOval(x + w / 2 - 5, y + h / 2 - 5, 10, 10);
        g2d.fillOval(x + w / 4 - 5, y + 3 * h / 4 - 5, 10, 10);
        g2d.fillOval(x + 3 * w / 4 - 5, y + 3 * h / 4 - 5, 10, 10);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Butcher's Broom");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new ButchersBroom());
        frame.setSize(200, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}